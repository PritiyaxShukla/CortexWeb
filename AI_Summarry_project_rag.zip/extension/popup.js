async function getCurrentTabUrl() {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab.url;
  }
  
  async function scrapeWebsite(url) {
    document.getElementById("status").textContent = "Scrap in progress";
    const summaryBtn = document.getElementById("summaryBtn");
    const qaBtn = document.getElementById("qaBtn");
    const questionInput = document.getElementById("questionInput");
  
    summaryBtn.disabled = true;
    qaBtn.disabled = true;
    questionInput.disabled = true;
  
    try {
      const res = await fetch("http://localhost:5000/scrape", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
  
      const result = await res.json();
  
      if (res.ok) {
        console.log("[EXTENSION] Scraping done:", result);
        document.getElementById("status").textContent = "Scrping completed!";
        summaryBtn.disabled = false;
        qaBtn.disabled = false;
        questionInput.disabled = false;
      } else {
        document.getElementById("status").textContent = "Scraping failed.";
        console.error("[EXTENSION] Scrape error:", result.error);
      }
    } catch (error) {
      console.error("[EXTENSION] Fetch error:", error);
      document.getElementById("status").textContent = "Error during scraping.";
    }
  }
  
  document.addEventListener("DOMContentLoaded", async () => {
    const url = await getCurrentTabUrl();
    console.log("[EXTENSION] Current URL:", url);
    scrapeWebsite(url);
  
    document.getElementById("summaryBtn").addEventListener("click", async () => {
      try {
        const res = await fetch("http://localhost:5000/summary");
        const data = await res.json();
        document.getElementById("output").textContent = data.summary || data.error;
      } catch (e) {
        console.error("[EXTENSION] Summary error:", e);
      }
    });
  
    document.getElementById("qaBtn").addEventListener("click", async () => {
      const question = document.getElementById("questionInput").value;
      if (!question) return alert("enter your question");
  
      try {
        const res = await fetch(`http://localhost:5000/qa?question=${encodeURIComponent(question)}`);
        const data = await res.json();
        document.getElementById("output").textContent = data.answer || data.error;
      } catch (e) {
        console.error("[EXTENSION] QA error:", e);
      }
    });
  });
  