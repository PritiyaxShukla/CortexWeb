import requests

url = "https://rto-vehicle-details.p.rapidapi.com/api3"

payload = { "vehicle_number": "UP37S2556" }
headers = {
	"x-rapidapi-key": "d4e48a86e9mshd38dc96dea27ac3p1e6e80jsn9be60588f4cd",
	"x-rapidapi-host": "rto-vehicle-details.p.rapidapi.com",
	"Content-Type": "application/json"
}

response = requests.post(url, json=payload, headers=headers)

print(response.json())