from langchain_core.prompts import PromptTemplate
from langchain.output_parsers import StructuredOutputParser , ResponseSchema
from langchain_core.messages import SystemMessage , HumanMessage , AIMessage
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_together import ChatTogether
from langchain_community.document_loaders import TextLoader
from langchain.schema.runnable import RunnableParallel , RunnableSequence
from dotenv import load_dotenv
import os

schema = [ResponseSchema(name="Answer", description="give the answer of the query Question from the given Avialble data understand the data and give the valid and accurate answer according to the data and also mention that the output Answer is given from the given data . ")]

parser = StructuredOutputParser.from_response_schemas(schema)

#text = f"{SystemMessage(content="You are a helpful AI Assistance")}"

prompt = PromptTemplate(
    template= "You are a Helpfull Assistance who gives the Answer from the following database data given only \n {data} \n in given format {formatted_output}",
    input_variables = ['data'],
    partial_variables= {"formatted_output": parser.get_format_instructions()}
)

new = prompt.invoke("hello my name is Master")
print(new)


'''
text='You are an AI Text Summarizer. Read the input text and provide a clear, concise summary that captures the key points, making it quick and easy for a human to understand in less time. Keep the summary short, informative, and easy to read. \n from the following the \n hello my name is Master , \n The output should be a markdown code snippet formatted in the following schema, including the leading and trailing "```json" and "```":\n\n```json\n{\n\t"summaries": string  // A list of short summaries for each phase of the text\n}\n```'

'''


'''
You are a helpful assistant. Answer the given question strictly based **only** on the following database text:

hello

Respond with a markdown code snippet formatted in **strict JSON**, following this exact schema.
Make sure your answer is derived from the given data and state that explicitly.

```json
{
  "Answer": "string (your detailed answer based ONLY on the provided data. Do NOT use outside knowledge. Mention that this is based on the provided data in Answer in Last line.)"
}
```
(base) PS C:\Users\user\ML LEARNING S\PROJECTS\chrome_extension> 
'''